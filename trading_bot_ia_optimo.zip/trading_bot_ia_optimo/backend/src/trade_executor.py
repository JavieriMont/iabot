import ccxt
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

exchange = ccxt.binance({
    'apiKey': API_KEY,
    'secret': API_SECRET,
    'enableRateLimit': True,
})

# exchange.set_sandbox_mode(True)

def create_market_order(symbol='BTC/USDT', side='buy', amount=0.001):
    try:
        order = exchange.create_market_order(symbol, side, amount)
        print(f"✅ Orden {side.upper()} ejecutada: {order}")
        return order
    except Exception as e:
        print(f"❌ Error al ejecutar orden {side.upper()}: {str(e)}")
        return None