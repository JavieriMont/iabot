def create_features(df, window=3):
    for i in range(1, window + 1):
        df[f'close_shift_{i}'] = df['close'].shift(i)
        df[f'rsi_shift_{i}'] = df['rsi'].shift(i)
    return df.dropna()