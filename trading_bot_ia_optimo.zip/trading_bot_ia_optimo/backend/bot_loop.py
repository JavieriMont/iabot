import time
import pandas as pd
from src.data_loader import get_ohlcv
from src.indicators import add_indicators
from src.features import create_features
from src.model import train_model
from src.trade_executor import create_market_order
from datetime import datetime
import os

symbols = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT']
order_size = 0.001
log_file = 'trade_log.csv'
last_signals = {}
last_prices = {}
trailing_stops = {}
take_profits = {}

TP_FACTOR = 2  # 2x ATR como Take Profit
TS_FACTOR = 1.2  # 1.2x ATR como Trailing Stop

def log_trade(symbol, signal, price, profit):
    data = {
        'timestamp': [datetime.utcnow()],
        'symbol': [symbol],
        'signal': [signal],
        'price': [price],
        'profit': [profit]
    }
    df = pd.DataFrame(data)
    if not os.path.exists(log_file):
        df.to_csv(log_file, index=False)
    else:
        df.to_csv(log_file, mode='a', index=False, header=False)

def run_bot():
    for symbol in symbols:
        try:
            df = get_ohlcv(symbol=symbol)
            df = add_indicators(df)
            df = create_features(df)
            model, acc = train_model(df)
            features = [col for col in df.columns if 'shift' in col or col in ['rsi', 'macd', 'ema_fast', 'ema_slow', 'atr']]
            prediction = model.predict(df[features].iloc[[-1]])[0]
            signal = 'BUY' if prediction == 1 else 'SELL'
            price = df['close'].iloc[-1]
            atr = df['atr'].iloc[-1]

            if symbol not in last_signals:
                last_signals[symbol] = signal
                last_prices[symbol] = price
                trailing_stops[symbol] = price - TS_FACTOR * atr if signal == 'BUY' else price + TS_FACTOR * atr
                take_profits[symbol] = price + TP_FACTOR * atr if signal == 'BUY' else price - TP_FACTOR * atr
                continue

            if last_signals[symbol] == 'BUY':
                if price >= take_profits[symbol] or price <= trailing_stops[symbol]:
                    create_market_order(symbol, 'sell', order_size)
                    profit = price - last_prices[symbol]
                    log_trade(symbol, 'SELL_TP' if price >= take_profits[symbol] else 'SELL_TS', price, profit)
                    last_signals[symbol] = 'SELL'
                    last_prices[symbol] = price
            elif last_signals[symbol] == 'SELL':
                if price <= take_profits[symbol] or price >= trailing_stops[symbol]:
                    create_market_order(symbol, 'buy', order_size)
                    profit = last_prices[symbol] - price
                    log_trade(symbol, 'BUY_TP' if price <= take_profits[symbol] else 'BUY_TS', price, profit)
                    last_signals[symbol] = 'BUY'
                    last_prices[symbol] = price

            if signal != last_signals[symbol]:
                side = 'buy' if signal == 'BUY' else 'sell'
                create_market_order(symbol, side, order_size)
                profit = price - last_prices[symbol] if signal == 'SELL' else 0
                log_trade(symbol, signal, price, profit)
                last_signals[symbol] = signal
                last_prices[symbol] = price
                trailing_stops[symbol] = price - TS_FACTOR * atr if signal == 'BUY' else price + TS_FACTOR * atr
                take_profits[symbol] = price + TP_FACTOR * atr if signal == 'BUY' else price - TP_FACTOR * atr

        except Exception as e:
            print(f"❌ Error procesando {symbol}: {e}")

if __name__ == '__main__':
    while True:
        run_bot()
        print("⏳ Esperando 1 hora para próxima ejecución...
")
        time.sleep(3600)