from flask import Flask, jsonify
from src.data_loader import get_ohlcv
from src.indicators import add_indicators
from src.features import create_features
from src.model import train_model
from src.trade_executor import create_market_order

app = Flask(__name__)

@app.route('/api/signal', methods=['GET'])
def get_signal():
    df = get_ohlcv()
    df = add_indicators(df)
    df = create_features(df)
    model, acc = train_model(df)
    features = [col for col in df.columns if 'shift' in col or col in ['rsi', 'macd', 'ema']]
    prediction = model.predict(df[features].iloc[[-1]])[0]
    signal = "BUY" if prediction == 1 else "HOLD"
    if prediction == 1:
        create_market_order('BTC/USDT', 'buy', 0.001)
    return jsonify({
        'symbol': 'BTC/USDT',
        'signal': signal,
        'confidence': float(acc),
        'time': df['timestamp'].iloc[-1].isoformat()
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
from flask import request

@app.route('/api/manual_trade', methods=['POST'])
def manual_trade():
    side = request.args.get('side')
    symbol = 'BTC/USDT'  # puedes parametrizar si quieres
    create_market_order(symbol, side, 0.001)
    return jsonify({'status': 'success', 'side': side})

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    if os.path.exists('trade_log.csv'):
        df = pd.read_csv('trade_log.csv')
        df = df[df['symbol'] == 'BTC/USDT']
        return jsonify({
            'symbol': 'BTC/USDT',
            'price': df['price'].iloc[-1],
            'total_profit': float(df['profit'].sum()),
            'num_trades': int(df['signal'].count())
        })
    return jsonify({'error': 'No data'})

from flask import request, session, redirect, url_for

app.secret_key = "super_secret_key"  # cambia esto por una clave segura

@app.before_request
def require_login():
    open_routes = ['/login', '/static']
    if request.path.startswith('/api') or any(request.path.startswith(route) for route in open_routes):
        return
    if 'logged_in' not in session:
        return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.form or request.json
        username = data.get('username')
        password = data.get('password')
        if username == 'admin' and password == 'admin123':
            session['logged_in'] = True
            return redirect('/')
        return "Credenciales inválidas", 401
    return '''
    <form method="post">
        <input name="username" placeholder="Usuario">
        <input name="password" type="password" placeholder="Contraseña">
        <input type="submit" value="Iniciar sesión">
    </form>
    '''

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect('/login')