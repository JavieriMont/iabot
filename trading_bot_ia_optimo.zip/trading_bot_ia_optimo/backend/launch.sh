#!/bin/bash
echo "📦 Iniciando entorno del bot..."
cd "$(dirname "$0")"
source venv/bin/activate 2>/dev/null || echo "⚠️ Asegúrate de tener un entorno virtual activado"
pip install -r requirements.txt
echo "🚀 Lanzando bot IA 24/7..."
python bot_loop.py