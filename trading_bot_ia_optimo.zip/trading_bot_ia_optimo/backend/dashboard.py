import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
import os

log_path = "trade_log.csv"

st.set_page_config(page_title="Bot IA Trading Dashboard", layout="wide")
st.title("📈 Dashboard de Rendimiento del Bot IA")

if os.path.exists(log_path):
    df = pd.read_csv(log_path, parse_dates=['timestamp'])

    st.subheader("📋 Historial Reciente")
    st.dataframe(df.tail(20))

    st.subheader("📊 Resumen por Criptomoneda")
    summary = df.groupby('symbol').agg(
        total_profit=('profit', 'sum'),
        num_trades=('signal', 'count'),
        last_price=('price', 'last')
    ).reset_index()
    st.dataframe(summary)

    st.subheader("📈 Gráficos Individuales por Criptomoneda")
    symbols = df['symbol'].unique()
    for symbol in symbols:
        symbol_df = df[df['symbol'] == symbol].copy()
        symbol_df['cumulative_profit'] = symbol_df['profit'].cumsum()

        st.markdown(f"### {symbol}")
        st.line_chart(symbol_df.set_index('timestamp')['cumulative_profit'])

else:
    st.warning("Aún no hay datos de trading disponibles.")