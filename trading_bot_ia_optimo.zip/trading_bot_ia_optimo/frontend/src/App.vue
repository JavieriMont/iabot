<template>
  <div class="container">
    <h1>Bot de Trading con IA</h1>
    <SignalDisplay />
    <ManualControls />
    <StreamlitDashboard />
  </div>
</template>

<script setup>
import SignalDisplay from './components/SignalDisplay.vue'
import StreamlitDashboard from './components/StreamlitDashboard.vue'
import ManualControls from './components/ManualControls.vue'
</script>