<template>
  <div class="manual-controls">
    <h2>⚙️ Control Manual y Métricas</h2>
    <div class="buttons">
      <button @click="executeTrade('buy')">Comprar Manualmente</button>
      <button @click="executeTrade('sell')">Vender Manualmente</button>
    </div>
    <div class="metrics" v-if="metrics">
      <p><strong>Último símbolo:</strong> {{ metrics.symbol }}</p>
      <p><strong>Precio actual:</strong> ${{ metrics.price }}</p>
      <p><strong>Ganancia acumulada:</strong> ${{ metrics.total_profit.toFixed(2) }}</p>
      <p><strong>Total operaciones:</strong> {{ metrics.num_trades }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const metrics = ref(null)

const fetchMetrics = async () => {
  const res = await fetch('/api/metrics')
  metrics.value = await res.json()
}

const executeTrade = async (side) => {
  await fetch(`/api/manual_trade?side=${side}`, { method: 'POST' })
  alert(`Orden ${side.toUpperCase()} enviada`)
}

onMounted(fetchMetrics)
</script>

<style scoped>
.manual-controls {
  margin-top: 2rem;
}
.buttons button {
  margin-right: 1rem;
  padding: 0.5rem 1rem;
}
</style>