<template>
  <div v-if="signal">
    <p><strong>Símbolo:</strong> {{ signal.symbol }}</p>
    <p><strong>Señal:</strong> {{ signal.signal }}</p>
    <p><strong>Confianza IA:</strong> {{ (signal.confidence * 100).toFixed(2) }}%</p>
    <p><strong>Hora:</strong> {{ signal.time }}</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const signal = ref(null);

onMounted(async () => {
  const res = await fetch('/api/signal');
  signal.value = await res.json();
});
</script>