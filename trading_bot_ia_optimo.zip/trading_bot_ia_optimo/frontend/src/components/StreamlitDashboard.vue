<template>
  <div class="dashboard">
    <h2>Dashboard de Rendimiento (IA)</h2>
    <iframe
      src="http://localhost:8501"
      width="100%"
      height="800"
      frameborder="0"
      style="border:1px solid #ccc; border-radius:8px"
    ></iframe>
  </div>
</template>

<script setup>
// Este componente muestra el dashboard de Streamlit embebido
</script>